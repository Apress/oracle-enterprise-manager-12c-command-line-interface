#!/bin/sh
################################################################################
#  File:       emclil_relocate_target_vcs.sh
#  Purpose:    Relocate OEM agent for monitored VCS targets
#  Parameters: VCS group name required
#  Note:       Must be run placed in VCS startup to run after fail-over
#              to the secondary host
################################################################################
# Environment tests
# ------------------------------------------------------------------------------
if [ ${#1} -eq 0 ]; then
   echo "You must pass the VCS cluster name on the command line\n\n"
   exit 1
fi

export VCSBIN=< Set to the bin directory for your VRTSvcs executables >

if [ ! -d ${VCSBIN} ]; then
   echo  "Could not locate the Veritas executables in ${VCSBIN}"
   export VCSBIN=""
   exit 1
fi	

# ------------------------------------------------------------------------------
# Variables section
# ------------------------------------------------------------------------------
SCRIPTNAME=`basename ${0}`
LOCAL_HOST=`hostname | cut -d"." -f1`

# Set the ORACLE_HOME to the agent's base directory
# EM agent installs with its own jdk, so reference it in this script

export ORACLE_HOME=/u01/oracle/product/agent12c
export EMCTL_HOME=${ORACLE_HOME}/agent_inst/bin
export JAVA_HOME=${ORACLE_HOME}/core/12.1.0.3.0/jdk/bin

# These settings assume EM CLI binaries reside in the agent O/H

export EMCLI_HOME=${ORACLE_HOME}/emcli

# Set paths to match the values set above

export PATH=${VCS_BIN}:${PATH}
export PATH=${ORACLE_HOME}:${ORACLE_HOME}/bin:${PATH}
export PATH=${EMCTL_HOME}:${PATH}
export PATH=${JAVA_HOME}:${PATH}
export PATH=${EMCLI_HOME}:${PATH}

export PATH=${PATH}:.
export LD_LIBRARY_PATH=${ORACLE_HOME}/lib:/lib:/lib64:/usr/lib:/usr/lib64

# Set fully-qualified paths to the executables here

export EMCLI=${EMCLI_HOME}/emcli
export EMCTL=${EMCTL_HOME}/emctl
export JAVA=${JAVA_HOME}/java

export IBM_JAVA_OPTIONS=-Djava.net.preferIPv4Stack=true	

# Required setting for an AIX environment

export AIXTHREAD_SCOPE=S


# ------------------------------------------------------------------------------
# File name variables - keep these in the same order as CleanUpFiles function
# ------------------------------------------------------------------------------
# Lists will be collected from each of source as listed and distilled into the
# final EM CLI script
#
# emcli relocate_targets verb syntax is slightly different for databases and 
# listeners so we'll collect them in separate lists of targets for processing

VCS_DATABASES=/tmp/RelocateTargetDatabases_VCS.lst
VCS_LISTENERS=/tmp/RelocateTargetListeners_VCS.lst

EMCLI_DATABASES=/tmp/RelocateTargetDatabases_EMCLI.lst
EMCLI_LISTENERS=/tmp/RelocateTargetListeners_EMCLI.lst

EMCTL_DATABASES=/tmp/RelocateTargetDatabases_EMCTL.lst
EMCTL_LISTENERS=/tmp/RelocateTargetListeners_EMCTL.lst

OEM_DATABASES=/tmp/RelocateTargetDatabases_OEM.lst
OEM_LISTENERS=/tmp/RelocateTargetListeners_OEM.lst

MOVING_DATABASES=/tmp/RelocateTargetDatabases_Moving.lst
MOVING_LISTENERS=/tmp/RelocateTargetListeners_Moving.lst

EMCLI_SCRIPT=/tmp/RelocateTarget_emcli_script.lst

#===============================================================================
# Functions
# ------------------------------------------------------------------------------
function CleanUpFiles {
[ $VCS_DATABASES ] && rm -f ${VCS_DATABASES}
[ $VCS_LISTENERS ] && rm -f ${VCS_LISTENERS}
[ $EMCLI_DATABASES ] && rm -f ${EMCLI_DATABASES}
[ $EMCLI_LISTENERS ] && rm -f ${EMCLI_LISTENERS}
[ $EMCTL_DATABASES ] && rm -f ${EMCTL_DATABASES}
[ $EMCTL_LISTENERS ] && rm -f ${EMCTL_LISTENERS}
[ $OEM_DATABASES ] && rm -f ${OEM_DATABASES}
[ $OEM_LISTENERS ] && rm -f ${OEM_LISTENERS}
[ $MOVING_DATABASES ] && rm -f ${MOVING_DATABASES}
[ $MOVING_LISTENERS ] && rm -f ${MOVING_LISTENERS}
[ $EMCLI_SCRIPT ] && rm -f ${EMCLI_SCRIPT}
}

function ExitCleanly {
CleanUpFiles
exit 0
}

function ExitDirty {
CleanUpFiles
exit 1
}

function ListNicely {
for thisLINE in `cat ${thisFILE}`; do
   echo "  ${thisLINE}"
done
}

#===============================================================================
# Runtime procedure
# ------------------------------------------------------------------------------
# Time stamp for the VCS log file

echo "\n\n\n---------------------------------------------------------------------"
date
echo "---------------------------------------------------------------------\n\n\n"

CleanUpFiles

# ------------------------------------------------------------------------------
# Gather VCS values for the members of the cluster
# ------------------------------------------------------------------------------
# Test whether VCS recognizes the cluster name you passed at the commmand line
# by checking for the existence of node in OFFLINE mode.  From that knowledge 
# we can get the name of the HAGROUP and then associate the offline and online
# nodes with the appropriate variable based on their status after the
# VCS fail-over

if [ `sudo ${VCSBIN}/hastatus -summary | grep OFFLINE | grep ${1} | wc -l` -eq 0 ]; then
   echo "\n\nThe VCS cluster ${1} does not exist on ${LOCAL_HOST}\n\n"
   ExitDirty
else
   export HAGROUP=`sudo ${VCSBIN}/hastatus -summary | grep OFFLINE | grep ${1} | awk '{ print $2 }'`
   export OFFLINE_NODE=`sudo ${VCSBIN}/hastatus -summary | grep OFFLINE | grep ${HAGROUP} | awk '{ print $3 }'`
   if [ `sudo ${VCSBIN}/hastatus -summary | grep ONLINE | grep ${HAGROUP} | wc -l` -gt 0 ]; then
      export ONLINE_NODE=`sudo ${VCSBIN}/hastatus -summary | grep ONLINE | grep ${HAGROUP} | awk '{ print $3 }'`
   else
      export ONLINE_NODE=`sudo ${VCSBIN}/hastatus -summary | grep PARTIAL | grep ${HAGROUP} | awk '{ print $3 }'`
   fi
fi

# Echo the values for the log file

echo "\n\nVeritas Cluster names:"
echo "  VCS group                     ${HAGROUP}"
echo "  Active node after relocation  ${ONLINE_NODE}"
echo "  Offline node                  ${OFFLINE_NODE}"
echo "  Local hostname                ${LOCAL_HOST}"

# Select the database and listener names associated with the HAGROUP
# This list may not match the list of targets known to OEM on these hosts, so we'll compare
# them later in the script

sudo ${VCSBIN}/hares -display -type Oracle  | grep ${HAGROUP} | awk '{ print $1 }' >${VCS_DATABASES}
sudo ${VCSBIN}/hares -display -type Netlsnr | grep ${HAGROUP} | awk '{ print $1 }' >${VCS_LISTENERS}

if [ `cat ${VCS_DATABASES} | wc -l` -gt 0 ]; then
   echo "\n\nVCS shows these databases in ${HAGROUP} group"
   thisFILE=${VCS_DATABASES}
   ListNicely
else
   echo "\n\nVCS has no databases associated with ${HAGROUP} group" 
   ExitDirty	  
fi	

if [ `cat ${VCS_LISTENERS} | wc -l` -gt 0 ]; then
	echo "\n\nVCS shows these listeners in ${HAGROUP} group"
	thisFILE=${VCS_LISTENERS}
	ListNicely
else	
	echo "\n\nVCS has no listeners associated with ${HAGROUP} group"
fi	

if [ ${OFFLINE_NODE} == ${LOCAL_HOST} ]; then
   echo "\n\nThe ${HAGROUP} group is located on the other side of the cluster"
   echo "This script must be run on the active node ${ONLINE_NODE}\n\n\n"
   ExitDirty
fi	  		  

# ------------------------------------------------------------------------------
# Get OEM agent names for both nodes
# Agents are always installed on a static file system and never fail over
# ------------------------------------------------------------------------------
NEW_EMD=`$EMCLI get_targets | grep ${ONLINE_NODE}  | grep oracle_emd |  awk '{print $NF }'`
OLD_EMD=`$EMCLI get_targets | grep ${OFFLINE_NODE} | grep oracle_emd |  awk '{print $NF }'`

# This string will be used several times during emcli script construction

EMCLI_AGENT_STRING=`echo "-src_agent=\"${OLD_EMD}\" -dest_agent=\"${NEW_EMD}\""`

echo "\n\nOEM names for the host targets related to this change:"
echo "  Host after relocation         ${NEW_EMD}"
echo "  Local host name               ${OLD_EMD}"

# ------------------------------------------------------------------------------
# Create and distill lists of OEM targets
# Not all targets are managed by OEM, so we need to get a list from the repository
# that we'll compare with the list from VCS
# ------------------------------------------------------------------------------
$EMCLI get_targets | grep oracle_database | awk '{print $NF}' | sort -fu >${EMCLI_DATABASES}

echo "\n\nDatabase targets managed through OEM:"
thisFILE=${EMCLI_DATABASES}
ListNicely

$EMCLI get_targets | grep oracle_listener | awk '{print $NF}' | sort -fu >${EMCLI_LISTENERS}
echo "\n\nListener targets managed through OEM:"
thisFILE=${EMCLI_LISTENERS}
ListNicely

# Now we'll do the same thing for targets known to the local EM agent.  This list
# may include targets ignored or unpromoted in the repository, so we'll treat the
# agent list as a better choice.  If the local agent has no targets we'll use
# the full list from the repository 

$EMCTL config agent listtargets | grep oracle_database | cut -d"[" -f2 | cut -d, -f1 | sort -fu  >${EMCTL_DATABASES}
echo "\n\nLocal database targets currently associated with ${NEW_EMD}:"
thisFILE=${EMCTL_DATABASES}
ListNicely

$EMCTL config agent listtargets | grep oracle_listener | cut -d"[" -f2 | cut -d, -f1 | sort -fu  >${EMCTL_LISTENERS}
echo "\n\nLocal listener targets currently associated with ${NEW_EMD}:"
thisFILE=${EMCTL_LISTENERS}
ListNicely

# The longer list from the repository was created in case the local agent did not
# contain any targets.  We'll replace the OMR list with the targets known to the 
# local agent if any exist

if [ `cat ${EMCTL_DATABASES} | wc -l` -gt 0 ]; then
   cat /dev/null                            >${OEM_DATABASES}	  
   for thisTARGET in `cat ${EMCLI_DATABASES}`; do
      if [ `cat ${EMCTL_DATABASES} | grep -i ${thisTARGET} | wc -l` -eq 0 ]; then
         echo "${thisTARGET}"              >>${OEM_DATABASES}
      fi
   done
else
   mv -f ${EMCLI_DATABASES} ${OEM_DATABASES}
fi	

# Same process happens for the listeners

if [ `cat ${EMCTL_LISTENERS} | wc -l` -gt 0 ]; then
   cat /dev/null                            >${OEM_LISTENERS}	  
   for thisTARGET in `cat ${EMCLI_LISTENERS}`; do
      if [ `cat ${EMCTL_LISTENERS} | grep -i ${thisTARGET} | wc -l` -eq 0 ]; then
         echo "${thisTARGET}"              >>${OEM_LISTENERS}
      fi
   done
else
   mv -f ${EMCLI_LISTENERS} ${OEM_LISTENERS}  	  	  
fi	


# ------------------------------------------------------------------------------
# Compare the OEM target list with the Veritas members and build emcli scripts
# ------------------------------------------------------------------------------

if [ `cat ${VCS_DATABASES} | wc -l` -gt 0 ]; then
   cat /dev/null                            >${MOVING_DATABASES}	  
   for thisITEM in `cat ${VCS_DATABASES}`; do
      cat ${OEM_DATABASES} | grep -i ${thisITEM} >>${MOVING_DATABASES}
   done
fi	

cat /dev/null                            >${EMCLI_SCRIPT}	  

if [ `cat ${MOVING_DATABASES} | wc -l` -gt 0 ]; then
   echo "\n\nThese database targets will be relocated"
   thisFILE=${MOVING_DATABASES}
   ListNicely
   for thisITEM in `cat ${MOVING_DATABASES}`; do
      EMCLI_TARGET_STRING=`echo "-target_name=\"${thisITEM}\" -target_type=\"oracle_database\""`
      echo "set_standby_agent ${EMCLI_AGENT_STRING} ${EMCLI_TARGET_STRING}"  >>${EMCLI_SCRIPT}
      echo "relocate_targets  ${EMCLI_AGENT_STRING} ${EMCLI_TARGET_STRING} -copy_from_src -force=yes" >>${EMCLI_SCRIPT}
   done	
else
   echo "\n\nNo database targets need to be migrated to ${NEW_EMD}"
fi

if [ `cat ${VCS_LISTENERS} | wc -l` -gt 0 ]; then
   cat /dev/null                            >${MOVING_LISTENERS}	  	  
   for thisITEM in `cat ${VCS_LISTENERS} | sed 's/lsnr//'`; do
      cat ${OEM_LISTENERS} | grep -i ${thisITEM} >>${MOVING_LISTENERS}
   done  	
else	
   echo "\n\nVCS has no listeners associated with ${HAGROUP} group"
fi	

if [ `cat ${MOVING_LISTENERS} | wc -l` -gt 0 ]; then
   echo "\n\nThese listener targets will be relocated to ${NEW_EMD}"
   thisFILE=${MOVING_LISTENERS}
   ListNicely
   for thisITEM in `cat ${MOVING_LISTENERS}`; do
      EMCLI_TARGET_STRING=`echo "-target_name=\"${thisITEM}\" -target_type=\"oracle_listener\""`			  
      echo "set_standby_agent ${EMCLI_AGENT_STRING} ${EMCLI_TARGET_STRING}" >>${EMCLI_SCRIPT}
      echo "relocate_targets  ${EMCLI_AGENT_STRING} ${EMCLI_TARGET_STRING} -copy_from_src" >>${EMCLI_SCRIPT}
   done
else
   echo "\n\nNo listener targets need to be migrated to ${NEW_EMD}"
fi

sleep 10

#  Show the emcli to the log file and then execute it with emcli argfile
if [ `cat ${EMCLI_SCRIPT} | wc -l` -gt 0 ]; then
   echo "\n\nEMCLI script"
   cat ${EMCLI_SCRIPT}
   echo "\n\nEMCLI execution results"
   $EMCLI argfile ${EMCLI_SCRIPT}
fi

echo "\n\nThese targets are now tracked by the local OEM agent:\n"
$EMCTL config agent listtargets | grep -v "Cloud" | grep -v "reserved." | sort -fu
echo "\n\n\n"

ExitCleanly
