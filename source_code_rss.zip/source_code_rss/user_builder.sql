SET ECHO OFF
SET FEEDBACK OFF HEADING OFF LINES 250 PAGES 999
SPOOL argfile_create_roles.txt

SELECT 'create_role -name="' || role_name || '" -description="' || description || '"'
FROM	 sysman.gc_roles
WHERE  role_type = '1';

SPOOL OFF

SPOOL argfile_create_users.txt

SELECT	 'create_user -name="' || user_name || '" -description="' || user_description || '" -password=�oracle� 
  -expired=�true�'
FROM		 sysman.gc_users
WHERE 	 user_name NOT IN ('SYSMAN')
ORDER BY user_name;

SPOOL OFF

SPOOL argfile_grant_roles.txt

SELECT 'grant_roles -name="' || user_name || '" -roles="' || role_name || '"'
FROM	 sysman.gc_user_roles;

SPOOL OFF